// DO NOT REMOVE, if needed, leave array blank []
var activate_box_selector = ['size'];
var color_boxes = [];

var colors = {
  'blu': '#95FFE4',
  'lightblue': '#95FFE4',

  'yellow': '#FFF695',
  'lightyellow': '#FFF695',

  'green': '#DEFFED',
  'lightgreen': '#DEFFED',

  'elektrisinine': '#0001E5',
  'electricultramarine': '#0001E5',

  'säravroosa': '#F400A1',
  'fashionfuchsia': '#F400A1',

  'heleroosa': '#FAC3D6',
  'lightpink': '#FAC3D6',

  'tumeroosa': '#FC2EAB',
  'hotpink': '#FC2EAB',

  'punane': '#FC0039',
  'red': '#FC0039',

  'sinine': '#0047BD',
  'blue': '#0047BD',

  'must': '#201F24',
  'black': '#201F24',

  'eremururoheline': '#7CFC00',
  'lawngreen': '#7CFC00',

  'sügavtaevasinine': '#00BFFF',
  'deepskyeblue': '#00BFFF',

  'tumesinine': '#003366',
  'darkblue': '#003366',

  'säravsinine': '#1E90FF',
  'dodgerblue': '#1E90FF',

  'purpur': '#800080',
  'purple': '#800080',

  'helepurpur': '#A1A3EE',
  'lightpurple': '#A1A3EE',

  'oranž': '#FD461D',
  'orange': '#FD461D',

  'beez': '#D9CBC2',
  'beige': '#D9CBC2'
};
